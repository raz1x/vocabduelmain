package de.htwberlin.userManager.export;

public class UserDAOPersistenceException extends Exception {
    public UserDAOPersistenceException(String message) {
        super(message);
    }
}