package de.htwberlin.vocab.export;

public class VocabListAlreadyExistsException extends Exception {
    public VocabListAlreadyExistsException(String message) {
        super(message);
    }
}
