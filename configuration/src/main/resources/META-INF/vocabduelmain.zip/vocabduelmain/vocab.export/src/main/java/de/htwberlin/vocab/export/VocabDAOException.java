package de.htwberlin.vocab.export;

public class VocabDAOException extends Exception {
    public VocabDAOException(String message) {
        super(message);
    }
}
