package de.htwberlin.vocab.export;

public class VocabListNotFoundException extends Exception {
    public VocabListNotFoundException(String message) {
        super(message);
    }
}
