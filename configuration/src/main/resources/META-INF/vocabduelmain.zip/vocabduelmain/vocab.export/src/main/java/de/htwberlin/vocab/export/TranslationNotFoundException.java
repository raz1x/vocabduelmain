package de.htwberlin.vocab.export;

public class TranslationNotFoundException extends Exception {
    public TranslationNotFoundException(String message) {
        super(message);
    }
}
