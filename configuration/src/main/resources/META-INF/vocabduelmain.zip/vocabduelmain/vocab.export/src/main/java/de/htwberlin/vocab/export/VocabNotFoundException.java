package de.htwberlin.vocab.export;

public class VocabNotFoundException extends Exception {
    public VocabNotFoundException(String message) {
        super(message);
    }
}
