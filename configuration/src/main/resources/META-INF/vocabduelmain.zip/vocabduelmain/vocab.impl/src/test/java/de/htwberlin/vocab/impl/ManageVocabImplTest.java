package de.htwberlin.vocab.impl;


import de.htwberlin.AppConfig;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

// TODO: Implement
// Probleme mit Spring DI

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class ManageVocabImplTest {

    public void testAddVocabList() {
    }

    public void testUpdateVocabList() {
    }

    public void testRemoveVocabList() {
    }

    public void testAddVocab() {
    }

    public void testUpdateVocab() {
    }

    public void testRemoveVocab() {
    }

    public void testAddTranslation() {
    }

    public void testUpdateTranslation() {
    }

    public void testRemoveTranslation() {
    }

    public void testAddCategory() {
    }

    public void testUpdateCategory() {
    }

    public void testRemoveCategory() {
    }

    public void testGetAllCategories() {
    }

    public void testParseVocabList() {
    }
}