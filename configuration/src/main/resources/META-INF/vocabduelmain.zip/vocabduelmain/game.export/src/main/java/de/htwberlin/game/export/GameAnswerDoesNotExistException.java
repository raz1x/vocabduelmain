package de.htwberlin.game.export;

public class GameAnswerDoesNotExistException extends Exception {
    public GameAnswerDoesNotExistException(String message) {
        super(message);
    }
}
