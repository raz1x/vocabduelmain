package de.htwberlin.game.export;

public class GameQuestionDoesNotExistException extends Exception {
    public GameQuestionDoesNotExistException(String message) {
        super(message);
    }
}
