package de.htwberlin.game.export;

public class RoundDoesNotExistException extends Exception {
    public RoundDoesNotExistException(String message) {
        super(message);
    }
}
