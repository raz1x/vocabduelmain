package de.htwberlin.game.export;

public class RoundResultDoesNotExistException extends Exception {
    public RoundResultDoesNotExistException(String message) {
        super(message);
    }
}
