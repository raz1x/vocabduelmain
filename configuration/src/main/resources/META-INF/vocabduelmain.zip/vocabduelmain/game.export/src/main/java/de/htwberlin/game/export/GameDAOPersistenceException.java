package de.htwberlin.game.export;

public class GameDAOPersistenceException extends Exception {
    public GameDAOPersistenceException(String message) {
        super(message);
    }
}
