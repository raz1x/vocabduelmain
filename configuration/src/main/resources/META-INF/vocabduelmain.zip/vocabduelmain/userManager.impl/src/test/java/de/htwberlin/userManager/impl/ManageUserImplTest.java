package de.htwberlin.userManager.impl;

import de.htwberlin.AppConfig;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

// TODO: Implement
// Probleme mit Spring DI

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = AppConfig.class)
public class ManageUserImplTest extends TestCase {

    public void testRegisterUser() {
    }

    public void testLoginUser() {
    }

    public void testLogoutUser() {
    }

    public void testDeleteUser() {
    }

    public void testUpdateUserName() {
    }

    public void testUpdatePassword() {
    }

    public void testGetByName() {
    }

    public void testGetById() {
    }

    public void testGetAllUsers() {
    }

    public void testGetOpponents() {
    }

    public void testUserExists() {
    }
}